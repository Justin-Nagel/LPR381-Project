﻿namespace Common
{
    public enum InequalitySign
    {
        EqualTo,
        LessThanOrEqualTo,
        GreaterThanOrEqualTo
    }
}
